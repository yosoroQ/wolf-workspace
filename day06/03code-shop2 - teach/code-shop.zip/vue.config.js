/*
 * @Author: iou2008 25844550@qq.com
 * @Date: 2022-10-31 14:37:51
 * @LastEditors: iou2008 25844550@qq.com
 * @LastEditTime: 2022-10-31 14:41:20
 * @FilePath: \爬虫相关e:\项目\狼\湛江实训\1031\code-shop\vue.config.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
const { defineConfig } = require("@vue/cli-service");
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave: false, // 关闭eslint
});
